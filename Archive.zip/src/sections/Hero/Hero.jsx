import styles from './HeroStyles.module.css';

function Hero() {
  return <section id='hero'>
    <>Some other text</>
    <div></div>
    </section>
}

export default Hero;