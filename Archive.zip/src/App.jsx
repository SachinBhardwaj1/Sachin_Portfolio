import './App.css'
import Hero from './sections/Hero/Hero';

function App() {
  console.log('test');
  return (
    <>
      <Hero/>
    </>
    );
}

export default App;
